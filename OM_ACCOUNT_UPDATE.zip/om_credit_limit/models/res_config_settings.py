from odoo import models, fields, api, _


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    account_credit_limit = fields.Boolean(
        string=u"Limite de crédit de vente", related="company_id.account_credit_limit", readonly=False,
        help="Enable credit limit for the current company.")
    account_default_credit_limit = fields.Monetary(
        string=u"Limite de crédit par défaut", related="company_id.account_default_credit_limit", readonly=False,
        help="A limit of zero means no limit by default.")