# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class FollowupFollowup(models.Model):
    _name = 'followup.followup'
    _description = 'Account Follow-up'

    name = fields.Char(related='company_id.name', string="Nom", readonly=True)
    followup_line = fields.One2many('followup.line', 'followup_id', 'Suivi', copy=True)
    company_id = fields.Many2one('res.company', 'Compagnie', required=True, default=lambda self: self.env.company)

    _sql_constraints = [('company_uniq', 'unique(company_id)',
                         'Only one follow-up per company is allowed')]


class FollowupLine(models.Model):
    _name = 'followup.line'
    _description = 'Follow-up Criteria'
    _order = 'delay'

    def _compute_sequence(self):
        delays = [line.delay for line in self.followup_id.followup_line]
        delays.sort()
        for line in self.followup_id.followup_line:
            sequence = delays.index(line.delay)
            line.sequence = sequence+1

    @api.model
    def default_get(self, default_fields):
        values = super(FollowupLine, self).default_get(default_fields)
        if self.env.ref('om_account_followup.email_template_om_account_followup_default'):
            values['email_template_id'] = self.env.ref('om_account_followup.email_template_om_account_followup_default').id
        return values

    name = fields.Char('Action de suivi', required=True)
    sequence = fields.Integer('Sequence', compute='_compute_sequence',
                              store=False,
                              help="Gives the sequence order when displaying a list of follow-up lines.")
    followup_id = fields.Many2one('followup.followup', 'Suivis',
                                  required=True, ondelete="cascade")
    delay = fields.Integer('Jours d’échéance',
                           help="The number of days after the due date of the "
                                "invoice to wait before sending the reminder. Could be negative if you want "
                                "to send a polite alert beforehand.",
                           required=True)
    description = fields.Text(u'Message imprimé', translate=True, default="""
        Dear %(partner_name)s,

Exception faite s’il y a eu une erreur de notre part, il semble que le suivant
montant reste impayé. Veuillez prendre les mesures appropriées afin de réaliser
ce paiement dans les 8 prochains jours.

Votre paiement aurait-il été effectué après l’envoi de ce courrier?
ignorer ce message. N’hésitez pas à contacter notre service comptabilité.

Cordialement,
""", )
    send_email = fields.Boolean('Envoyer un mail', default=True,
                                help="When processing, it will send an email")
    send_letter = fields.Boolean('Envoyer une Lettre', default=True,
                                 help="When processing, it will print a letter")
    manual_action = fields.Boolean('Action Manuel', default=False,
                                   help="When processing, it will set the "
                                        "manual action to be taken for that customer. ")
    manual_action_note = fields.Text(u'Action à faire')
    manual_action_responsible_id = fields.Many2one('res.users',
                                                   string=u'Désigner un responsable', ondelete='set null')
    email_template_id = fields.Many2one('mail.template', 'Email Template',
                                        ondelete='set null')

    _sql_constraints = [('days_uniq', 'unique(followup_id, delay)',
                         'Days of the follow-up levels must be different')]

    @api.constrains('description')
    def _check_description(self):
        for line in self:
            if line.description:
                try:
                    line.description % {'partner_name': '', 'date': '',
                                        'user_signature': '',
                                        'company_name': ''}
                except ValidationError:
                    raise ValidationError(
                        _('Your description is invalid, use the right legend '
                          'or %% if you want to use the percent character.'))
