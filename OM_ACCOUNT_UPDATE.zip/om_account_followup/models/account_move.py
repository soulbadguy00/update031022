# -*- coding: utf-8 -*-

from odoo import api, fields, models, _


class AccountMoveLine(models.Model):
    _inherit = 'account.move.line'

    followup_line_id = fields.Many2one('followup.line', 'Niveau de suivi')
    followup_date = fields.Date('Dernier suivi')
    result = fields.Float(compute='_get_result', string="Montant de la balance")

    def _get_result(self):
        for aml in self:
            aml.result = aml.debit - aml.credit
