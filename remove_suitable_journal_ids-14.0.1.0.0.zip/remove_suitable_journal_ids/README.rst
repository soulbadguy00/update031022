=======================================
REMOVE SUITABLE JOURNAL IDS
=======================================

remove_suitable_journal_ids

Installation
============

No special needs or modules.

Credits
=======

Contributors
------------

* Nicolás Ramos <contacto@nicolasramos.es>
